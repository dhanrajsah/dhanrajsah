const navToggle = document.querySelector('.nav-toggle');
const navMenu = document.querySelector('.nav-menu');
const navLinks = document.querySelectorAll('.nav-link');
const backToTopBtn = document.getElementById('backToTop');
const cursorDot = document.querySelector('.cursor-dot');
const cursorRing = document.querySelector('.cursor-ring');
const interactiveSelectors = 'a, button, .skill-card, .project-card, .nav-link, .social-link, .skill-action, .project-link, .glass-card';

let mouseX = 0;
let mouseY = 0;
let ringX = 0;
let ringY = 0;

if (navToggle) {
    navToggle.addEventListener('click', () => {
        const expanded = navToggle.getAttribute('aria-expanded') === 'true';
        navToggle.setAttribute('aria-expanded', String(!expanded));
        navMenu.classList.toggle('active');
    });
}

navLinks.forEach((link) => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        navToggle.setAttribute('aria-expanded', 'false');
    });
});

window.addEventListener('mousemove', (event) => {
    mouseX = event.clientX;
    mouseY = event.clientY;

    if (cursorDot) {
        cursorDot.style.transform = `translate(${mouseX}px, ${mouseY}px)`;
    }
});

const animateRing = () => {
    ringX += (mouseX - ringX) * 0.18;
    ringY += (mouseY - ringY) * 0.18;

    if (cursorRing) {
        cursorRing.style.transform = `translate(${ringX}px, ${ringY}px)`;
    }

    requestAnimationFrame(animateRing);
};

requestAnimationFrame(animateRing);

const prefersReducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

document.querySelectorAll(interactiveSelectors).forEach((node) => {
    node.addEventListener('mouseenter', () => {
        if (!prefersReducedMotion) document.body.classList.add('cursor-hover');
    });
    node.addEventListener('mouseleave', () => {
        if (!prefersReducedMotion) document.body.classList.remove('cursor-hover');
    });
});


const revealElements = document.querySelectorAll('.reveal');
const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            revealObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.18, rootMargin: '0px 0px -80px 0px' });

revealElements.forEach((element, index) => {
    element.style.transitionDelay = `${index * 55}ms`;
    revealObserver.observe(element);
});

const tiltCards = document.querySelectorAll('.skill-card, .project-card');
tiltCards.forEach((card) => {
    card.addEventListener('pointermove', (event) => {
        const rect = card.getBoundingClientRect();
        const px = (event.clientX - rect.left) / rect.width;
        const py = (event.clientY - rect.top) / rect.height;

        const rotateY = (px - 0.5) * 10;
        const rotateX = (0.5 - py) * 10;

        // Use CSS variables so CSS hover/glow doesn't fight JS transforms.
        card.style.setProperty('--rx', `${rotateX}deg`);
        card.style.setProperty('--ry', `${rotateY}deg`);
        card.style.setProperty('--tz', '6px');
    });

    card.addEventListener('pointerleave', () => {
        card.style.removeProperty('--rx');
        card.style.removeProperty('--ry');
        card.style.setProperty('--tz', '0px');
    });
});


const sections = document.querySelectorAll('section[id]');
const setActiveNav = () => {
    const scrollPosition = window.pageYOffset + 160;
    let currentId = '';

    sections.forEach((section) => {
        const sectionTop = section.offsetTop;
        if (scrollPosition >= sectionTop) {
            currentId = section.getAttribute('id');
        }
    });

    navLinks.forEach((link) => {
        const isActive = link.getAttribute('href') === `#${currentId}`;
        link.classList.toggle('active', isActive);
    });
};

const setBackgroundPosition = () => {
    const offset = window.scrollY * 0.06;
    document.documentElement.style.setProperty('--bg-pos', `calc(50% + ${offset}px)`);
};

const setScrollEffects = () => {
    if (backToTopBtn) {
        if (window.pageYOffset > 360) {
            backToTopBtn.classList.add('visible');
        } else {
            backToTopBtn.classList.remove('visible');
        }
    }
    setActiveNav();
    setBackgroundPosition();
};

window.addEventListener('scroll', setScrollEffects);
setScrollEffects();

if (backToTopBtn) {
    backToTopBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

const loader = document.querySelector('.loader');
window.addEventListener('load', () => {
    if (loader) {
        loader.classList.add('hidden');
        setTimeout(() => loader.remove(), 550);
    }
});

const skillsData = {
    'web-dev': {
        title: 'Web Development',
        icon: '<i class="fas fa-code"></i>',
        description: 'I design and build responsive, visually appealing, and user-friendly websites using modern web technologies. I focus on clean layouts, efficient coding practices, and intuitive navigation to create websites that provide an excellent user experience. My expertise includes HTML, CSS, JavaScript, and creating dynamic, interactive web applications that work seamlessly across all devices.'
    },
    'programming': {
        title: 'Programming (C Language)',
        icon: '<i class="fas fa-laptop-code"></i>',
        description: 'I have learned the fundamentals of programming through C, developing strong problem-solving skills and logical thinking. I apply these skills to small projects, algorithm practice, and computational tasks, which helps me understand programming concepts more deeply. This foundational knowledge enables me to approach complex problems systematically and develop efficient solutions.'
    },
    'computer-science': {
        title: 'Computer Science Fundamentals',
        icon: '<i class="fas fa-desktop"></i>',
        description: 'I have studied core concepts in computer science including algorithms, data structures, and basic computing principles. This knowledge forms the foundation for my programming and web development projects. Understanding these fundamentals allows me to write more efficient code, optimize performance, and tackle complex technical challenges with confidence.'
    },
    'business': {
        title: 'Business & Economics',
        icon: '<i class="fas fa-chart-line"></i>',
        description: 'Being a student of business economics, I understand key concepts in finance, accounting, and market operations. This knowledge allows me to approach projects with a practical perspective, combining technical skills with business awareness. I can analyze market trends, understand financial statements, and make informed decisions that bridge the gap between technology and business strategy.'
    },
    'accounting': {
        title: 'Accounting Basics',
        icon: '<i class="fas fa-calculator"></i>',
        description: 'I have practical knowledge of accounting principles, bookkeeping, and financial analysis, which strengthens my understanding of business processes and supports my analytical skills. This expertise helps me manage finances effectively, prepare accurate reports, and understand the financial health of organizations. My accounting knowledge complements my technical abilities perfectly.'
    },
    'content': {
        title: 'Content Creation',
        icon: '<i class="fas fa-pen-fancy"></i>',
        description: 'I enjoy creating educational and informative content, particularly for my project Silent Voice Nepal. This includes writing articles, creating social media posts, and sharing knowledge with a wider audience to promote awareness on social and educational topics. My content creation skills help me communicate complex ideas clearly and engage audiences effectively across multiple platforms.'
    },
    'communication': {
        title: 'Communication & Teamwork',
        icon: '<i class="fas fa-users"></i>',
        description: 'I am skilled in effective communication, collaboration, and leadership. I value working in teams, sharing ideas, and managing projects efficiently, which ensures that all tasks are completed with high quality. My ability to communicate clearly, listen actively, and work collaboratively makes me an effective team member and leader in any project or organization.'
    }
};

const skillModal = document.getElementById('skillModal');
const modalTitle = document.getElementById('modalTitle');
const modalDescription = document.getElementById('modalDescription');
const modalIcon = document.getElementById('modalIcon');
const modalClose = document.querySelector('.skill-modal-close');

const openSkillModal = (skill) => {
    if (!skillModal || !modalTitle || !modalDescription || !modalIcon) return;

    modalTitle.textContent = skill.title;
    modalDescription.textContent = skill.description;
    modalIcon.innerHTML = skill.icon;
    skillModal.classList.add('active');
    document.body.style.overflow = 'hidden';
};

const closeSkillModal = () => {
    if (!skillModal) return;
    skillModal.classList.remove('active');
    document.body.style.overflow = '';
};

if (skillModal && modalClose) {
    document.querySelectorAll('.skill-card').forEach((card) => {
        const button = card.querySelector('.skill-action');
        if (!button) return;

        button.addEventListener('click', () => {
            const key = card.dataset.skill;
            const skill = skillsData[key];
            if (skill) openSkillModal(skill);
        });
    });

    modalClose.addEventListener('click', closeSkillModal);
    skillModal.addEventListener('click', (event) => {
        if (event.target === skillModal) {
            closeSkillModal();
        }
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && skillModal.classList.contains('active')) {
            closeSkillModal();
        }
    });
}

const contactForm = document.getElementById('contactForm');
const submitBtn = document.getElementById('submitBtn');

if (contactForm) {
    contactForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.textContent = 'Sending...';
        }

        const nameEl = document.getElementById('name');
        const emailEl = document.getElementById('email');
        const messageEl = document.getElementById('message');

        const name = nameEl ? nameEl.value : '';
        const email = emailEl ? emailEl.value : '';
        const message = messageEl ? messageEl.value : '';
        const text = `New Portfolio Message:\n\nName: ${name}\nEmail: ${email}\nMessage: ${message}`;

        try {
            const response = await fetch('https://api.telegram.org/bot7594325949:AAH6hgwJiv77PeUw4-s4VzIWbOghUtpQGmE/sendMessage', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ chat_id: '6085885404', text })
            });

            if (response.ok) {
                alert('Thank you! Your message has been sent successfully.');
                contactForm.reset();
            } else {
                alert('Telegram API Error. Please check your Bot Token.');
            }
        } catch (error) {
            alert('Connection error! Please check your internet.');
        } finally {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Send Message';
            }
        }
    });
}

console.log('Hard-Level portfolio interaction system initialized.');
